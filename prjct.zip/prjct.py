import subprocess

from win32com.client import Dispatch
from datetime import datetime
import webbrowser


def say(text):
    speak = Dispatch("SAPI.SpVoice").Speak
    speak(text)


def dateTime():
    # datetime object containing current date and time
    now = datetime.now()

    print("now =", now)

    # dd/mm/YY H:M:S
    dt_string_date = now.strftime("%d/%m/%Y")
    dt_string_time = now.strftime("%H:%M:%S")
    print("date and time =", dt_string_time,dt_string_date)
    return dt_string_date,dt_string_time


def takeCommand():
    query=input("Enter task :")
    return query


if __name__ == '__main__':
    print("pycharm")
    d, t = dateTime()
    say("Hello i am Hector A  I")
    say(f"current date is {d}")
    say(f"and current time is {t}")
    while(True):
        text = takeCommand()
        if "youtube" in text.lower():
            say("Opening youtube for you..")
            webbrowser.open("https://youtube.com")
        elif "facebook" in text.lower():
                say("Opening face book for you..")
                webbrowser.open("https://facebook.com")
        elif "wikipedia" in text.lower():
                say("Opening wiki pedia for you..")
                webbrowser.open("https://wikipedia.com")
        elif "blogger" in text.lower():
                say("Opening blogger for you..")
                webbrowser.open("https://blogger.com")
        elif "linkedin" in text.lower():
                say("Opening linkdin for you..")
                webbrowser.open("https://linkedin.com")
        elif "play music" in text.lower():
            from playsound import playsound
            n=input("Enter name of song in download folder : ")
            print("Playing your  music")
            playsound(f'{n}.mp3')
        if "exit" in text.lower():
            exit()




